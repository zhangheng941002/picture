/*
 Auth:zh
 Website: www.zzhgod.com
 Date:2019-10-22 
 user_content:字段类型是josn
*/

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user`  (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '用户名',
  `password` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '密码',
  `email` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '邮箱',
  `major` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `status` int(12) NOT NULL COMMENT '状态，1：可用，0：注销',
  `user_content` varchar(45) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES (1, '用户名01', '123456', '923103984@qq.com', '中文系', 1, '{\"position\": \"干事\", \"time\": \"2年\"}');
INSERT INTO `user` VALUES (2, '用户名02', '123456', '1@1.com', '经管系', 0, '{\"position\":\"部长\", \"time\": \"1年\"}');
INSERT INTO `user` VALUES (3, '用户名03', '123456', 'test@test.com', '中文系', 1, '{\"position\":\"学生\", \"time\":\"4年\"}');
INSERT INTO `user` VALUES (4, '用户名04', '123456', '11@163.com', '其他系', 0, '{\"time\": \"4年\"}');
INSERT INTO `user` VALUES (5, '用户名05', '123456', '123@123.com', '外语系', 1, '{\"time\": \"4年\"}');

SET FOREIGN_KEY_CHECKS = 1;
